import { useRef } from "react";
import { motion, useInView } from "framer-motion";

const HeroSection = () => {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section
      ref={ref}
      className="flex flex-col items-center justify-center text-center relative px-6 overflow-hidden pt-20 pb-4"
      style={{ minHeight: "22vh" }}
    >
      <div className="nebula-overlay" />

      {/* Glow orb behind title */}
      <div
        className="absolute"
        style={{
          width: "600px",
          height: "300px",
          background: "radial-gradient(ellipse, hsla(45,95%,58%,0.06) 0%, transparent 70%)",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          pointerEvents: "none",
        }}
      />

      {/* Eyebrow */}
      <motion.div
        className="flex items-center gap-2 mb-6"
        initial={{ opacity: 0, y: 20 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <div
          className="w-5 h-px"
          style={{ background: "hsl(var(--gold))" }}
        />
        <span className="gold-text text-xs font-body font-semibold tracking-[0.4em] uppercase">
          Discover the Universe
        </span>
        <div
          className="w-5 h-px"
          style={{ background: "hsl(var(--gold))" }}
        />
      </motion.div>

      {/* Main title */}
      <motion.h1
        className="font-display font-black leading-none mb-3 relative z-10"
        style={{ fontSize: "clamp(2.5rem, 6vw, 5rem)", letterSpacing: "-0.04em" }}
        initial={{ opacity: 0, y: 40 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 1, delay: 0.3, ease: [0.23, 1, 0.32, 1] }}
      >
        <span className="heading-glow">Reddit </span>
        <span className="gold-text" style={{ textShadow: "0 0 60px hsla(45,95%,58%,0.4), 0 0 120px hsla(45,95%,58%,0.15)" }}>
          X
        </span>
      </motion.h1>

      {/* Subtitle */}
      <motion.p
        className="font-body text-sm max-w-md mx-auto mb-5 leading-relaxed"
        style={{ color: "hsl(var(--silver-dim))" }}
        initial={{ opacity: 0, y: 20 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.8, delay: 0.5 }}
      >
        A cosmic gallery of discovery — curated content, infinite worlds.
      </motion.p>

      {/* CTA */}
      <motion.button
        className="font-body font-semibold px-6 py-2.5 rounded-full text-xs tracking-widest uppercase transition-all duration-300"
        style={{
          background: "hsl(var(--gold))",
          color: "hsl(0,0%,4%)",
          boxShadow: "0 0 30px hsla(45,95%,58%,0.35), 0 4px 20px hsla(0,0%,0%,0.5)",
          letterSpacing: "0.15em",
        }}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={isInView ? { opacity: 1, scale: 1 } : {}}
        transition={{ duration: 0.6, delay: 0.7 }}
        whileHover={{ scale: 1.05, boxShadow: "0 0 50px hsla(45,95%,58%,0.5), 0 4px 30px hsla(0,0%,0%,0.6)" }}
        whileTap={{ scale: 0.97 }}
      >
        Explore Now
      </motion.button>
    </section>
  );
};

export default HeroSection;
