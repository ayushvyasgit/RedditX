import { useEffect, useRef } from "react";

interface Star {
  x: number;
  y: number;
  z: number;
  size: number;
  opacity: number;
  twinkleSpeed: number;
  twinklePhase: number;
}

const StarfieldBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let mouseX = 0;
    let mouseY = 0;
    let targetMouseX = 0;
    let targetMouseY = 0;

    const STAR_COUNT = 480;
    const stars: Star[] = [];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    const onMouseMove = (e: MouseEvent) => {
      targetMouseX = (e.clientX / window.innerWidth - 0.5) * 2;
      targetMouseY = (e.clientY / window.innerHeight - 0.5) * 2;
    };
    window.addEventListener("mousemove", onMouseMove);

    // Create stars with varying z-depth
    for (let i = 0; i < STAR_COUNT; i++) {
      stars.push({
        x: Math.random() * 2 - 1,
        y: Math.random() * 2 - 1,
        z: Math.random(),
        size: Math.random() * 1.8 + 0.3,
        opacity: Math.random() * 0.6 + 0.2,
        twinkleSpeed: Math.random() * 0.02 + 0.005,
        twinklePhase: Math.random() * Math.PI * 2,
      });
    }

    // Occasional slightly colored stars
    const nebulaColors = [
      "rgba(180,200,255,",
      "rgba(255,220,180,",
      "rgba(200,180,255,",
      "rgba(255,255,255,",
    ];

    let t = 0;
    const render = () => {
      t += 0.012;
      // Smooth mouse follow
      mouseX += (targetMouseX - mouseX) * 0.04;
      mouseY += (targetMouseY - mouseY) * 0.04;

      const W = canvas.width;
      const H = canvas.height;
      const cx = W / 2;
      const cy = H / 2;

      ctx.clearRect(0, 0, W, H);

      // Cosmic gradient background
      const bg = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(W, H) * 0.8);
      bg.addColorStop(0, "hsl(230, 35%, 5%)");
      bg.addColorStop(0.5, "hsl(230, 20%, 3%)");
      bg.addColorStop(1, "hsl(0, 0%, 2%)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);

      // Subtle nebula clouds
      const nebulaA = ctx.createRadialGradient(W * 0.15, H * 0.4, 0, W * 0.15, H * 0.4, W * 0.35);
      nebulaA.addColorStop(0, "hsla(310,50%,18%,0.18)");
      nebulaA.addColorStop(1, "transparent");
      ctx.fillStyle = nebulaA;
      ctx.fillRect(0, 0, W, H);

      const nebulaB = ctx.createRadialGradient(W * 0.85, H * 0.6, 0, W * 0.85, H * 0.6, W * 0.3);
      nebulaB.addColorStop(0, "hsla(210,55%,14%,0.15)");
      nebulaB.addColorStop(1, "transparent");
      ctx.fillStyle = nebulaB;
      ctx.fillRect(0, 0, W, H);

      // Render stars
      stars.forEach((star, i) => {
        const twinkle = Math.sin(t * star.twinkleSpeed * 80 + star.twinklePhase) * 0.3 + 0.7;
        const depth = star.z; // 0 = far, 1 = near
        const parallaxStrength = depth * 22;

        const sx = (star.x * 0.5 + 0.5) * W + mouseX * parallaxStrength;
        const sy = (star.y * 0.5 + 0.5) * H + mouseY * parallaxStrength;

        const size = star.size * (0.4 + depth * 0.8);
        const alpha = star.opacity * twinkle;

        const colorIdx = i % nebulaColors.length;
        const baseColor = colorIdx === 3 ? "rgba(255,255,255," : nebulaColors[colorIdx];

        // Glow for brighter stars
        if (depth > 0.6 && size > 1.2) {
          const grd = ctx.createRadialGradient(sx, sy, 0, sx, sy, size * 4);
          grd.addColorStop(0, `${baseColor}${alpha * 0.4})`);
          grd.addColorStop(1, `${baseColor}0)`);
          ctx.fillStyle = grd;
          ctx.beginPath();
          ctx.arc(sx, sy, size * 4, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.beginPath();
        ctx.arc(sx, sy, size, 0, Math.PI * 2);
        ctx.fillStyle = `${baseColor}${alpha})`;
        ctx.fill();
      });

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMouseMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      id="starfield-canvas"
      style={{ position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none" }}
    />
  );
};

export default StarfieldBackground;
