import { useRef, useEffect, useCallback } from "react";
import MomentumCard, { CardData } from "./MomentumCard";

interface CardRowProps {
  cards: CardData[];
}

const CardRow = ({ cards }: CardRowProps) => {
  const rowRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);
  const startX = useRef(0);
  const scrollLeft = useRef(0);
  const velocity = useRef(0);
  const lastX = useRef(0);
  const animId = useRef<number>(0);

  // Momentum scroll
  const applyMomentum = useCallback(() => {
    const el = rowRef.current;
    if (!el) return;
    velocity.current *= 0.94;
    if (Math.abs(velocity.current) > 0.5) {
      el.scrollLeft += velocity.current;
      animId.current = requestAnimationFrame(applyMomentum);
    }
  }, []);

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    isDragging.current = true;
    startX.current = e.pageX - (rowRef.current?.offsetLeft ?? 0);
    scrollLeft.current = rowRef.current?.scrollLeft ?? 0;
    lastX.current = e.pageX;
    cancelAnimationFrame(animId.current);
  }, []);

  const onMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging.current || !rowRef.current) return;
    e.preventDefault();
    velocity.current = e.pageX - lastX.current;
    lastX.current = e.pageX;
    const x = e.pageX - rowRef.current.offsetLeft;
    rowRef.current.scrollLeft = scrollLeft.current - (x - startX.current);
  }, []);

  const onMouseUp = useCallback(() => {
    isDragging.current = false;
    animId.current = requestAnimationFrame(applyMomentum);
  }, [applyMomentum]);

  useEffect(() => {
    return () => cancelAnimationFrame(animId.current);
  }, []);

  return (
    <div
      ref={rowRef}
      className="card-row-scroll flex gap-3 pb-2 select-none"
      style={{ paddingLeft: "2rem", paddingRight: "2rem" }}
      onMouseDown={onMouseDown}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseUp}
    >
      {/* Duplicate for infinite feel */}
      {[...cards, ...cards].map((card, i) => (
        <MomentumCard key={`${card.id}-${i}`} card={card} index={i} />
      ))}
    </div>
  );
};

export default CardRow;
