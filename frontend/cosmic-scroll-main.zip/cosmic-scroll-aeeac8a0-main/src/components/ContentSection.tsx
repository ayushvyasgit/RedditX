import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import CardRow from "./CardRow";
import { CardData } from "./MomentumCard";

interface ContentSectionProps {
  sectionTitle: string;
  sectionSubtitle?: string;
  cards: CardData[];
  accentLine?: string;
}

const ContentSection = ({ sectionTitle, sectionSubtitle, cards, accentLine }: ContentSectionProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-120px" });

  return (
    <section
      ref={sectionRef}
      className="flex flex-col justify-center py-4 relative overflow-hidden"
    >
      {/* Nebula overlay per section */}
      <div className="nebula-overlay" />

      {/* Section header */}
      <div className="px-8 md:px-16 mb-3 relative z-10">
        {accentLine && (
          <motion.p
            initial={{ opacity: 0, x: -20 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="gold-text font-body text-sm font-semibold tracking-[0.3em] uppercase mb-3"
          >
            {accentLine}
          </motion.p>
        )}

        <motion.h2
          className="heading-glow font-display text-3xl md:text-4xl font-black leading-none"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.15, ease: [0.23, 1, 0.32, 1] }}
        >
          {sectionTitle}
        </motion.h2>

        {sectionSubtitle && (
          <motion.p
            className="mt-1 text-xs max-w-xl"
            style={{ color: "hsl(var(--silver-dim))" }}
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.3 }}
          >
            {sectionSubtitle}
          </motion.p>
        )}

        {/* Gold divider line */}
        <motion.div
          className="mt-3 h-px"
          style={{ background: "linear-gradient(to right, hsl(var(--gold)), transparent)" }}
          initial={{ scaleX: 0, originX: 0 }}
          animate={isInView ? { scaleX: 1 } : {}}
          transition={{ duration: 1, delay: 0.4, ease: [0.23, 1, 0.32, 1] }}
        />
      </div>

      {/* Card row */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.8, delay: 0.35, ease: [0.23, 1, 0.32, 1] }}
        className="relative z-10"
      >
        <CardRow cards={cards} />
      </motion.div>
    </section>
  );
};

export default ContentSection;
