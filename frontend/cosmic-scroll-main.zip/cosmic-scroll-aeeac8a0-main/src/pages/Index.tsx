import StarfieldBackground from "@/components/StarfieldBackground";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import ContentSection from "@/components/ContentSection";
import { CardData } from "@/components/MomentumCard";

// ── Image imports ──────────────────────────────────
import cricketStadium from "@/assets/cricket-stadium.jpg";
import cricketBat from "@/assets/cricket-bat.jpg";
import cricketBowl from "@/assets/cricket-bowl.jpg";
import aiNeural from "@/assets/ai-neural.jpg";
import aiRobot from "@/assets/ai-robot.jpg";
import aiChip from "@/assets/ai-chip.jpg";
import aiLlm from "@/assets/ai-llm.jpg";
import spaceNebula from "@/assets/space-nebula.jpg";
import natureMountain from "@/assets/nature-mountain.jpg";
import cityFuture from "@/assets/city-future.jpg";
import sportsCar from "@/assets/sports-car.jpg";
import oceanGlow from "@/assets/ocean-glow.jpg";

// ── Data ──────────────────────────────────────────

const interestCards: CardData[] = [
  {
    id: "i1",
    title: "Space Exploration",
    description: "Beyond the Milky Way — humanity's eternal quest for the stars.",
    image: spaceNebula,
    tag: "Science",
  },
  {
    id: "i2",
    title: "Alpine Wilderness",
    description: "Untouched peaks bathed in alpenglow at the edge of the world.",
    image: natureMountain,
    tag: "Nature",
  },
  {
    id: "i3",
    title: "Cyberpunk Futures",
    description: "Neon-soaked cityscapes and the cities of tomorrow.",
    image: cityFuture,
    tag: "Tech",
  },
  {
    id: "i4",
    title: "Hyperdrive Machines",
    description: "Engineering marvels that blur the line between speed and art.",
    image: sportsCar,
    tag: "Auto",
  },
  {
    id: "i5",
    title: "Deep Ocean Secrets",
    description: "Bioluminescent worlds hidden in the abyss, glowing in silence.",
    image: oceanGlow,
    tag: "Ocean",
  },
];

const cricketCards: CardData[] = [
  {
    id: "c1",
    title: "Stadium at Golden Hour",
    description: "The pitch awaits under a blazing sky as 80,000 fans hold their breath.",
    image: cricketStadium,
    tag: "Live",
  },
  {
    id: "c2",
    title: "The Perfect Drive",
    description: "Bat meets ball in a moment of pure, electric power.",
    image: cricketBat,
    tag: "Highlights",
  },
  {
    id: "c3",
    title: "The Art of Pace",
    description: "A fast bowler at full tilt — poetry in raw athletic form.",
    image: cricketBowl,
    tag: "Bowling",
  },
  {
    id: "c4",
    title: "Night Matches",
    description: "Floodlit drama, electric atmosphere, and last-over thrillers.",
    image: cricketStadium,
    tag: "T20",
  },
  {
    id: "c5",
    title: "World Cup Moments",
    description: "Historic balls, impossible catches, and legendary innings.",
    image: cricketBat,
    tag: "Classic",
  },
];

const aiCards: CardData[] = [
  {
    id: "a1",
    title: "Neural Networks",
    description: "The invisible lattice of intelligence woven through silicon and light.",
    image: aiNeural,
    tag: "Deep Learning",
  },
  {
    id: "a2",
    title: "The Machine Mind",
    description: "Sentient systems, emergent consciousness, and the future of robotics.",
    image: aiRobot,
    tag: "Robotics",
  },
  {
    id: "a3",
    title: "Silicon Dreams",
    description: "Semiconductor breakthroughs powering the next age of computing.",
    image: aiChip,
    tag: "Hardware",
  },
  {
    id: "a4",
    title: "Language Models",
    description: "Words shaped by probability — machines that read, write, and reason.",
    image: aiLlm,
    tag: "LLMs",
  },
  {
    id: "a5",
    title: "AI & Creativity",
    description: "Generative art, synthetic realities, and the boundary of expression.",
    image: aiNeural,
    tag: "GenAI",
  },
];

const Index = () => {
  return (
    <div
      className="relative"
      style={{ background: "hsl(var(--background))" }}
    >
      {/* Fixed 3D Starfield */}
      <StarfieldBackground />

      {/* Fixed Header */}
      <Header />

      {/* Snap-scroll main content */}
      <main style={{ position: "relative", zIndex: 1 }}>
        {/* Hero */}
        <HeroSection />

        {/* Your Interests */}
        <ContentSection
          sectionTitle="Your Interests"
          sectionSubtitle="Handpicked from the cosmos, tailored to your curiosity."
          accentLine="Curated For You"
          cards={interestCards}
        />

        {/* Cricket */}
        <ContentSection
          sectionTitle="Cricket"
          sectionSubtitle="The gentleman's game — now electrified. Every ball a universe."
          accentLine="Sport"
          cards={cricketCards}
        />

        {/* AI */}
        <ContentSection
          sectionTitle="Artificial Intelligence"
          sectionSubtitle="Silicon meets soul. The frontier where machines learn to dream."
          accentLine="Technology"
          cards={aiCards}
        />
      </main>

      {/* Footer */}
      <footer
        className="relative z-10 py-12 px-8 md:px-16 text-center"
        style={{ borderTop: "1px solid hsl(var(--border))" }}
      >
        <p className="font-display text-2xl mb-2 heading-glow">Reddit X</p>
        <p className="font-body text-sm" style={{ color: "hsl(var(--silver-dim))" }}>
          A cosmic gallery of discovery · Built for explorers
        </p>
        <div className="flex justify-center gap-8 mt-6 text-xs font-body tracking-widest uppercase" style={{ color: "hsl(var(--muted-foreground))" }}>
          {["Trending", "Cricket", "AI", "Science", "Culture", "Auto"].map((t) => (
            <button
              key={t}
              className="hover:text-gold transition-colors duration-200"
              style={{ color: "hsl(var(--silver-dim))" }}
              onMouseEnter={(e) => (e.currentTarget.style.color = "hsl(var(--gold))")}
              onMouseLeave={(e) => (e.currentTarget.style.color = "hsl(var(--silver-dim))")}
            >
              {t}
            </button>
          ))}
        </div>
      </footer>
    </div>
  );
};

export default Index;
