import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Search, User, Zap } from "lucide-react";

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      className="fixed top-0 left-0 right-0 z-50 px-6 md:px-12 py-5 flex items-center justify-between transition-all duration-500"
      style={{
        background: scrolled
          ? "hsla(0,0%,2%,0.85)"
          : "transparent",
        backdropFilter: scrolled ? "blur(20px) saturate(1.5)" : "none",
        borderBottom: scrolled ? "1px solid hsla(0,0%,100%,0.06)" : "none",
      }}
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1] }}
    >
      {/* Logo */}
      <div className="flex items-center gap-3">
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ background: "hsl(var(--gold))", boxShadow: "0 0 16px hsla(45,95%,58%,0.5)" }}
        >
          <Zap className="w-4 h-4" style={{ color: "hsl(0,0%,5%)" }} />
        </div>
        <span
          className="font-display font-bold text-xl tracking-tight heading-glow"
          style={{ letterSpacing: "-0.03em" }}
        >
          Reddit<span className="gold-text"> X</span>
        </span>
      </div>

      {/* Search + user */}
      <div className="flex items-center gap-4">
        <motion.div
          className="flex items-center gap-3 px-4 py-2 rounded-full cursor-pointer transition-all duration-300"
          style={{
            background: "hsla(0,0%,100%,0.06)",
            border: "1px solid hsla(0,0%,100%,0.1)",
            width: searchOpen ? "220px" : "44px",
            overflow: "hidden",
          }}
          onClick={() => setSearchOpen(!searchOpen)}
          layout
        >
          <Search className="w-4 h-4 flex-shrink-0" style={{ color: "hsl(var(--silver-dim))" }} />
          {searchOpen && (
            <input
              autoFocus
              placeholder="Search topics…"
              className="bg-transparent outline-none text-sm flex-1"
              style={{ color: "hsl(var(--silver))", caretColor: "hsl(var(--gold))" }}
            />
          )}
        </motion.div>

        <button
          className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110"
          style={{
            background: "hsla(0,0%,100%,0.08)",
            border: "1px solid hsla(0,0%,100%,0.12)",
          }}
        >
          <User className="w-4 h-4" style={{ color: "hsl(var(--silver-dim))" }} />
        </button>
      </div>
    </motion.header>
  );
};

export default Header;
