import { useRef, useState } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";

export interface CardData {
  id: string;
  title: string;
  description: string;
  image: string;
  tag?: string;
}

interface MomentumCardProps {
  card: CardData;
  index: number;
}

const MomentumCard = ({ card, index }: MomentumCardProps) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  // Raw mouse-position motion values
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);

  // Spring config for silky momentum
  const springConfig = { damping: 18, stiffness: 160, mass: 0.6 };
  const springX = useSpring(rawX, springConfig);
  const springY = useSpring(rawY, springConfig);

  // Map spring values to rotation
  const rotateX = useTransform(springY, [-0.5, 0.5], [10, -10]);
  const rotateY = useTransform(springX, [-0.5, 0.5], [-10, 10]);

  // Shine position
  const shineX = useTransform(springX, [-0.5, 0.5], [0, 100]);
  const shineY = useTransform(springY, [-0.5, 0.5], [0, 100]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = cardRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    rawX.set(x);
    rawY.set(y);
  };

  const handleMouseLeave = () => {
    rawX.set(0);
    rawY.set(0);
    setIsHovered(false);
  };

  return (
    <motion.div
      ref={cardRef}
      className="relative flex-shrink-0 cursor-pointer"
      style={{
        width: "200px",
        height: "270px",
        perspective: "800px",
      }}
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.08, ease: [0.23, 1, 0.32, 1] }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
    >
      <motion.div
        className="momentum-card rounded-card overflow-hidden w-full h-full relative"
        style={{
          rotateX,
          rotateY,
          transformStyle: "preserve-3d",
          scale: isHovered ? 1.06 : 1,
          transition: "scale 0.35s cubic-bezier(0.23, 1, 0.32, 1)",
        }}
      >
        {/* Image — fills full card */}
        <div className="absolute inset-0">
          <img
            src={card.image}
            alt={card.title}
            className="w-full h-full object-cover"
            style={{ opacity: isHovered ? 0.95 : 0.85, transition: "opacity 0.4s ease" }}
          />
          {/* Gradient overlay — dark bottom for text */}
          <div
            className="absolute inset-0"
            style={{
              background: "linear-gradient(to bottom, hsla(0,0%,0%,0.18) 0%, hsla(0,0%,0%,0.5) 55%, hsla(0,0%,0%,0.92) 100%)",
            }}
          />
        </div>

        {/* Shine refraction effect */}
        {isHovered && (
          <motion.div
            className="absolute inset-0 rounded-card pointer-events-none"
            style={{
              background: `radial-gradient(circle at ${shineX.get()}% ${shineY.get()}%, hsla(0,0%,100%,0.12) 0%, transparent 60%)`,
              mixBlendMode: "screen",
            }}
          />
        )}

        {/* Tag pill */}
        {card.tag && (
          <div
            className="absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-semibold tracking-widest uppercase"
            style={{
              background: "hsla(45,95%,58%,0.18)",
              border: "1px solid hsla(45,95%,58%,0.4)",
              color: "hsl(var(--gold))",
              backdropFilter: "blur(8px)",
            }}
          >
            {card.tag}
          </div>
        )}

        {/* Content — bottom of card */}
        <div className="absolute bottom-0 left-0 right-0 p-3" style={{ transform: "translateZ(20px)" }}>
          <h3
            className="font-display font-bold text-sm leading-snug mb-1 gold-text"
            style={{ textShadow: "0 0 12px hsla(45,95%,58%,0.5)" }}
          >
            {card.title}
          </h3>
          <p
            className="text-xs leading-relaxed"
            style={{ color: "hsl(var(--silver-dim))" }}
          >
            {card.description}
          </p>
        </div>

        {/* Hover border glow */}
        <div
          className="absolute inset-0 rounded-card pointer-events-none transition-opacity duration-500"
          style={{
            border: "1px solid hsla(45,95%,58%,0.3)",
            opacity: isHovered ? 1 : 0,
            boxShadow: "inset 0 0 30px hsla(45,95%,58%,0.06)",
          }}
        />
      </motion.div>
    </motion.div>
  );
};

export default MomentumCard;
